import "./globals.css";
import kb from "@/data/knowledge_base.json";
import { ProgressProvider } from "@/lib/ProgressContext";
import Sidebar from "@/components/Sidebar";

export const metadata = {
  title: "Codex Arcanum",
  description: "A grimoire of code and machine",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <ProgressProvider kb={kb}>
          <div className="layout">
            <Sidebar kb={kb} />
            <main className="main">{children}</main>
          </div>
        </ProgressProvider>
      </body>
    </html>
  );
}
