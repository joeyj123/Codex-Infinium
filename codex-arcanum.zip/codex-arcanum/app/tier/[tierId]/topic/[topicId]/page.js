"use client";

import { useParams, useRouter, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import kb from "@/data/knowledge_base.json";
import { useProgress } from "@/lib/ProgressContext";

export default function TopicPage() {
  const { tierId, topicId } = useParams();
  const searchParams = useSearchParams();
  const lang = searchParams.get("lang");
  const router = useRouter();
  const { progress, markComplete, loaded } = useProgress();

  const tierIndex = kb.tiers.findIndex((t) => t.id === tierId);
  const tier = kb.tiers[tierIndex];
  const topic =
    tierId === "expert" && lang
      ? tier.language_tracks[lang].topics.find((t) => t.id === topicId)
      : tier.topics.find((t) => t.id === topicId);

  const [showHint, setShowHint] = useState(false);
  const [showExamples, setShowExamples] = useState(false);
  const [remaining, setRemaining] = useState(topic.min_read_seconds || 20);
  const [earned, setEarned] = useState(null);

  useEffect(() => {
    setRemaining(topic.min_read_seconds || 20);
    const interval = setInterval(() => {
      setRemaining((r) => Math.max(0, r - 1));
    }, 1000);
    return () => clearInterval(interval);
  }, [topic.id]);

  if (!loaded) return null;

  const done = progress.completedTopics.includes(topic.id);
  const backHref = tierId === "expert" && lang ? `/tier/expert?lang=${lang}` : `/tier/${tierId}`;

  function handleComplete() {
    const xp = markComplete(topic.id, tierIndex, topic.xp || 20, tier.name);
    setEarned(xp);
  }

  return (
    <div>
      <h1>{topic.title}</h1>
      <p className="stat-line">Worth {topic.xp || 20} XP</p>

      <p>{topic.explanation || "No content written yet for this topic."}</p>

      <div className="btn-row" style={{ marginTop: 16 }}>
        <button className="btn" onClick={() => setShowHint(!showHint)}>
          💡 Hint
        </button>
        <button className="btn" onClick={() => setShowExamples(!showExamples)}>
          📚 Examples
        </button>
      </div>

      {showHint && (
        <p style={{ marginTop: 12, color: "var(--muted)" }}>
          {topic.hint || "No hint written yet."}
        </p>
      )}
      {showExamples && (
        <p style={{ marginTop: 12, color: "var(--muted)" }}>
          {topic.examples || "No worked examples written yet."}
        </p>
      )}

      <div style={{ height: 1, background: "var(--border)", margin: "24px 0" }} />

      {done ? (
        <p style={{ color: "var(--success)" }}>✅ Completed</p>
      ) : earned !== null ? (
        <p style={{ color: "var(--success)" }}>+{earned} XP earned</p>
      ) : (
        <>
          <p>Earn XP for this topic:</p>
          <div className="btn-row">
            {remaining > 0 ? (
              <button className="btn" disabled>
                📖 Reading… {remaining}s
              </button>
            ) : (
              <button className="btn" onClick={handleComplete}>
                📖 Mark as Read
              </button>
            )}
            <button className="btn" onClick={() => alert("Practice mode not built yet — check back soon.")}>
              🎮 Practice
            </button>
            <button className="btn" onClick={() => alert("Exercise mode not built yet — check back soon.")}>
              ✏️ Exercise
            </button>
            <button className="btn" onClick={() => alert("Quiz mode not built yet — check back soon.")}>
              ❓ Quiz
            </button>
          </div>
        </>
      )}

      <div style={{ marginTop: 24 }}>
        <button className="btn" onClick={() => router.push(backHref)}>
          ⬅️ Back
        </button>
      </div>
    </div>
  );
}
