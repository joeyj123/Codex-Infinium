"use client";

import Link from "next/link";
import kb from "@/data/knowledge_base.json";
import { useProgress } from "@/lib/ProgressContext";

export default function Dashboard() {
  const { progress, rank, xpIntoRank, loaded } = useProgress();

  if (!loaded) return null;

  const currentTier = kb.tiers.find((t) => progress.unlockedTiers.includes(t.id) &&
    !(t.topics
      ? t.topics.every((x) => progress.completedTopics.includes(x.id)) && t.topics.length > 0
      : false)
  ) || kb.tiers[0];

  return (
    <div>
      <h1>Dashboard</h1>
      <p style={{ color: "var(--muted)" }}>Welcome back.</p>

      <div className="metric-row">
        <div className="metric">
          <div className="metric-value">{rank}</div>
          <div className="metric-label">RANK</div>
        </div>
        <div className="metric">
          <div className="metric-value">{progress.completedTopics.length}</div>
          <div className="metric-label">TOPICS DONE</div>
        </div>
        <div className="metric">
          <div className="metric-value">{progress.badges.length}</div>
          <div className="metric-label">BADGES</div>
        </div>
      </div>

      <div className="progress-track">
        <div className="progress-fill" style={{ width: `${xpIntoRank}%` }} />
      </div>
      <p className="stat-line">{xpIntoRank}/100 XP to Rank {rank + 1}</p>

      <div className="card" style={{ marginTop: 24 }}>
        <h4 style={{ marginTop: 0 }}>Continue where you left off</h4>
        <p style={{ marginBottom: 12 }}>
          {currentTier.icon} {currentTier.name}
        </p>
        <Link href={`/tier/${currentTier.id}`}>
          <button className="btn">Continue</button>
        </Link>
      </div>

      <Link href="/progression">
        <button className="btn" style={{ marginTop: 16 }}>
          🗺️ View Full Progression Map
        </button>
      </Link>
    </div>
  );
}
