"use client";

import Link from "next/link";
import { useProgress } from "@/lib/ProgressContext";

export default function TopicCard({ topic, tierId, langId }) {
  const { progress } = useProgress();
  const done = progress.completedTopics.includes(topic.id);
  const href = langId
    ? `/tier/${tierId}/topic/${topic.id}?lang=${langId}`
    : `/tier/${tierId}/topic/${topic.id}`;

  return (
    <div className="card">
      <div className="card-row">
        <p className="card-title">
          {done ? <span className="seal">✓</span> : <span style={{ fontSize: 16, color: "var(--muted)" }}>○</span>}
          {topic.title}
        </p>
        <Link href={href}>
          <button className="btn">{done ? "Review" : "Open"}</button>
        </Link>
      </div>
    </div>
  );
}
