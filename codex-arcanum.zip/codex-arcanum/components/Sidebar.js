"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useProgress } from "@/lib/ProgressContext";

export default function Sidebar({ kb }) {
  const pathname = usePathname();
  const { progress, rank, xpIntoRank } = useProgress();

  const currentTierIndex = kb.tiers.findIndex((t) =>
    progress.unlockedTiers.includes(t.id)
  );
  const unlockedTiers = kb.tiers.filter((t) => progress.unlockedTiers.includes(t.id));

  return (
    <aside className="sidebar">
      <h2 style={{ fontSize: 20, marginBottom: 2 }}>🔮 Codex Arcanum</h2>
      <p style={{ color: "var(--muted)", fontSize: 13, marginBottom: 18 }}>
        Learn Computer Science
      </p>

      <div className="stat-line">Rank {rank} · {xpIntoRank}/100 XP</div>
      <div className="progress-track">
        <div className="progress-fill" style={{ width: `${xpIntoRank}%` }} />
      </div>
      <div className="stat-line" style={{ marginBottom: 20 }}>
        Badges: {progress.badges.length}
      </div>

      <Link href="/">
        <button className={`nav-btn ${pathname === "/" ? "active" : ""}`}>
          📊 Dashboard
        </button>
      </Link>
      <Link href="/progression">
        <button className={`nav-btn ${pathname === "/progression" ? "active" : ""}`}>
          🗺️ Progression Map
        </button>
      </Link>

      <div style={{ height: 1, background: "var(--border)", margin: "14px 0" }} />
      <p style={{ fontSize: 12, color: "var(--muted)", marginBottom: 8, fontFamily: "'Cinzel', serif" }}>
        YOUR TIERS
      </p>

      {unlockedTiers.map((tier) => {
        const active = pathname.startsWith(`/tier/${tier.id}`);
        return (
          <Link href={`/tier/${tier.id}`} key={tier.id}>
            <button className={`nav-btn ${active ? "active" : ""}`}>
              {tier.icon} {tier.name}
            </button>
          </Link>
        );
      })}
    </aside>
  );
}
